<main>
    <h1>EDIT CATEGORY</h1>

    <?php foreach ($category as $category): ?>
        <form action="editcategory" method="POST">
            <label for="name">New category Name:</label>
            <input type="text" name="category_name" value="<?= $category['category_name'] ?>" required />

            <input type="hidden" name="idcategory" value="<?= $category['idcategory'] ?>" />

            <input type="submit" value="EDIT" name="edit" />
        </form>
    <?php endforeach; ?>
</main>
