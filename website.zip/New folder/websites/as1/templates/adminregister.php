<main>
    <h1>Admin Registration</h1>
    <form action="adminregister" method="POST">
        <label for="username">Username</label>
        <input type="text" name="username" />
        <?php if (isset($error['username'])): ?>
            <p><?php echo $error['username']; ?></p>
        <?php endif; ?>

        <label for="email">Email</label>
        <input type="email" name="email" />
        <?php if (isset($error['email'])): ?>
            <p><?php echo $error['email']; ?></p>
        <?php endif; ?>

        <label for="password">Password</label>
        <input type="password" name="password" />
        <?php if (isset($error['password'])): ?>
            <p><?php echo $error['password']; ?></p>
        <?php endif; ?>

        <input type="submit" value="Register" name="register" style="float: none;" />
    </form>
</main>
