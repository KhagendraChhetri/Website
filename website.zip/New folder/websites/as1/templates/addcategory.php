<main>
    <h1>ADD CATEGORY</h1>

        <form action="addcategory" method="POST">
            <label for="name">New category Name:</label>
            <input type="text" name="category_name" required />

            <input type="submit" value="ADD" name="add" />
        </form>
</main>
