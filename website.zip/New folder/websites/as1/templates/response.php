
<main>
<ul class='reviews'>
            <?php foreach ($questions as $question): ?>
                <li>
                    <p><?= $question['question_details'] ?></p>
        

                    <div class='details'>
                        <strong><?= $question['question_email'] ?></strong>
                        <em><?= $question['dateis'] ?></em>
                    </div>
                    
                </li>
           
        </ul>


        <h2>Add a reply</h2>
        <form action="response" method="post">
      
            <label>Write here:</label>
            <textarea name="content"><?= $question['answer'] ?></textarea>
            <input type="hidden" name="idquestion" value="<?= $question['idquestion'] ?>" />
            <label>Post status :</label>

            <select name="type">
                <option value="show">SHOW</option>
                <option value="hide">HIDE</option>
            </select>
            <input type="submit" name="reply" value="Submit" />
        </form>
        <?php endforeach; ?>
            </main>
