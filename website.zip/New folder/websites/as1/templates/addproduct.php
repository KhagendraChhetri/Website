<main>
    <h1>ADD PRODUCT</h1>
    <?php if (isset($error)): ?>
        <p><?php echo $error; ?></p>
    <?php endif; ?>
        <form action="addproduct" method="POST" enctype="multipart/form-data">
            <label for="name">New product Name:</label>
            <input type="text" name="product_name" required />

            <label for="price">Product Price:</label>
            <input type="text" name="product_price" required />

            <label for="price">Product Manufacture:</label>
            <input type="text" name="product_manufacturer" required />

            <label for="description">Product Description:</label>
            <textarea name="product_details" required></textarea>


            <label>Product Category</label> 


            <?php
               require('../database_connect.php');

        
            $query = $pdo->prepare('SELECT * FROM category');

            $query->execute();
            echo '<select name="idcategory">';
            while ($category =$query->fetch())
            {
                echo '<option value="'. $category['idcategory']. '">'.$category['category_name'].'</option>';
            }
            echo '</select>';
            ?>
            <!-- Submit button -->
            <input type="submit" value="ADD" name="add" />
        </form>
</main>
