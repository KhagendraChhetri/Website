

<main>
<h1>question List</h1>
<form action="" method="GET">
        <input type="hidden" name="filter" value="unreplied">
        <input type="submit" value="Show Unreplied Questions">
    </form>
<?php if (isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <table>
        <tr>
            <th>Question</th>
            <th>Replied</th>
            <th></th>
            <th></th>
           

        </tr>

        <?php foreach ($questions as $question): ?>
            <tr>
                <td style="max-width: 200px;"><?= $question['question_details'] ?></td>
                <td><?= $question['response'] == 1 ? 'Yes' : 'No' ?></td>
                <td>
                    <form action="response" method="GET">
								<input type="hidden" name="id" value="<?=$question['idquestion']?>">
								<input type="submit" value="REPLY">
							</form>
                </td>
                <td>
                            <form action="questionlist" method="POST">
								<input type="hidden" name="idquestion" value="<?=$question['idquestion']?>">
								<input type="submit" name="delete" value="DELETE" onclick="return confirm('Are you sure you want to delete this category?')">
							</form>                
                </td>
            </tr>
        <?php endforeach; ?>

    </table>


</main>