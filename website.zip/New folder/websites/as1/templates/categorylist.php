

<main>
<h1> CATEGORY LISTS</h1>
<h4 style="float: right;"><a href="addcategory">Add Category</a></h4>
<?php if (isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
<table>

        <tr>
            <th>Category Name</th>
            <th></th><th></th>

        </tr>
        <?php foreach ($category as $category): ?>

        <tr>
            <td><?= $category['category_name'] ?></td>
            <td>
                
                            <form action="/editcategory" method="GET">
								<input type="hidden" name="id" value="<?=$category['idcategory']?>">
								<input type="submit" value="EDIT">
							</form></td><td>
                            <form action="categorylist" method="POST">
								<input type="hidden" name="idcategory" value="<?=$category['idcategory']?>">
								<input type="submit" name="delete" value="DELETE" onclick="return confirm('Are you sure you want to delete this category?')">
							</form>
            </td>
        </tr>
<?php endforeach; ?>
</table>


</main>