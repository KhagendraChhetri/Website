<main>
    <h1>USER LOGIN</h1>
    <h4 style="float: right;"><a href="register">Register Here!!</a></h4>
    <form action="login" method="POST">
        <label>Email</label> <input type="email" name="email" required />
        <label>Password</label> <input type="password" name="password" required />
        <input type="submit" value="Login" name="login" />
    </form>
    <?php if (isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
</main>
