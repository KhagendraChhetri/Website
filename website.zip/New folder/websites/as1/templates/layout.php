<!doctype html>
<html>
	<head>
		<title>Ed's Electronics</title>
		<meta charset="utf-8" />
		<base href="/">
		<link rel="stylesheet" href="./electronics.css"/>
	</head>

	<body>
	<header>
    <h1>Ed's Electronics</h1>

    <?php
    require('../database_connect.php');

    $query = $pdo->prepare('SELECT * FROM category');
    $query->execute();

    if (isset($_SESSION['role']) && $_SESSION['role'] === 'admin'): ?>
        <!-- Admin menu -->
        <ul>
            <li><a href="/">Home</a></li>
            <li>Products
                <ul>
                    <?php while ($category = $query->fetch()): ?>
                        <li><a href="/productcategory?id=<?=$category['idcategory']?>"><?=$category['category_name']?></a></li>

                    <?php endwhile; ?>
                </ul>
            </li>
            <li><a href="dashboard">Dashboard</a></li>
        </ul>
    <?php elseif (isset($_SESSION['role']) && $_SESSION['role'] === 'client'): ?>
        <!-- Client menu -->
        <ul>
            <li><a href="#">Home</a></li>
            <li>Products
                <ul>
                    <?php $query->execute(); ?>
                    <?php while ($category = $query->fetch()): ?>
                        <li><a href="/productcategory?id=<?=$category['idcategory']?>"><?=$category['category_name']?></a></li>
                    <?php endwhile; ?>
                </ul>
            </li>
            <li><a href="dashboard">Dashboard</a></li>
        </ul>
    <?php else: ?>
        <!-- Default menu for users who are not logged in or do not have a role -->
        <ul>
            <li><a href="#">Home</a></li>
            <li>Products
                <ul>
                    <?php $query->execute(); ?>
                    <?php while ($category = $query->fetch()): ?>
                        <li><a href="/productcategory?id=<?=$category['idcategory']?>"><?=$category['category_name']?></a></li>

                    <?php endwhile; ?>
                </ul>
            </li>
            <li><a href="login">Login</a></li>
        </ul>
    <?php endif; ?>

    <address>
        <p>We are open 9-5, 7 days a week. Call us on
            <strong>01604 11111</strong>
        </p>
    </address>
</header>



        <section></section>
	
  
		<?=$output;?>

        <footer>
		&copy; Ed's Electronics 2023
</footer>
	</body>
</html>