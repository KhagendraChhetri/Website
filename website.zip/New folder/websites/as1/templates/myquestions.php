

<main>
<h1>question List</h1>
<?php if (isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <table>
        <tr>
            <th>Question</th>
            <th>Date</th>

            <th>Replied</th>
            <th></th>
            <th></th>
           

        </tr>

        <?php foreach ($questions as $question): ?>
            <tr>
                <td style="max-width: 300px;"><?= $question['question_details'] ?></td>
                <td><?= $question['dateis'] ?></td>

                <td><?= $question['response'] == 1 ? 'Yes' : 'No' ?></td>
                
                <td>
                            <form action="questionlist" method="POST">
								<input type="hidden" name="idquestion" value="<?=$question['idquestion']?>">
								<input type="submit" name="delete" value="DELETE" onclick="return confirm('Are you sure you want to delete this category?')">
							</form>                
                </td>
            </tr>
        <?php endforeach; ?>

    </table>


</main>