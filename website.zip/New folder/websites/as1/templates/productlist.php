

<main>
<h1> Product Management</h1>
<h4 style="float: right;"><a href="addproduct">Add Products</a></h4>
<?php if (isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
<table>

        <tr>
            <th>Product</th>
            <th>Price</th>
            <th>Manufacturer</th>
            <th></th><th></th>

        </tr>
        <?php foreach ($products as $product): ?>

        <tr>
        <td onclick="window.location.href='products?id=<?= $product['idproduct']; ?>'" onmouseover="this.style.transform='scale(1.25)'" onmouseout="this.style.transform='scale(1)'"><?= $product['product_name'] ?></td>
            <td><?= $product['product_price'] ?></td>
            <td><?= $product['product_manufacturer'] ?></td>

            <td>
                
                            <form action="/editproduct" method="GET">
								<input type="hidden" name="id" value="<?=$product['idproduct']?>">
								<input type="submit" value="EDIT">
							</form></td><td>
                            <form action="productlist" method="POST">
								<input type="hidden" name="idproduct" value="<?=$product['idproduct']?>">
								<input type="submit" name="delete" value="DELETE" onclick="return confirm('Are you sure you want to delete this product?')">
							</form>
            </td>
        </tr>
<?php endforeach; ?>
</table>


</main>