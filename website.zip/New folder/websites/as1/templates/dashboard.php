
<main>

    <h1>Welcome to the Dashboard, <?php echo $_SESSION['username']; ?>!</h1>

<?php if ($_SESSION['role'] === 'admin'): ?>
    <p>Hello Admin.</p>

    <div class="box-container">
        <div class="clickable-box"onclick="location.href='/productlist';">
            <h2>PRODUCTS</h2>
        </div>

        <div class="clickable-box" onclick="location.href='/categorylist';">
            <h2>CATEGORY</h2>
        </div>

        <div class="clickable-box" onclick="location.href='/userlist';">
            <h2>USERS</h2>
        </div>
    
        <div class="clickable-box" onclick="location.href='/questionlist';">
            <h2>Product Queries</h2>
        </div>
        <div class="clickable-box" onclick="location.href='/logout';">
            <h2>LOGOUT</h2>
        </div>
    </div>

    <?php elseif($_SESSION['role'] === 'client'): ?>

    <div class="box-container">
        <div class="clickable-box" onclick="location.href='/myquestions';">
            <h2>MY Question</h2>
        </div>

        <div class="clickable-box" onclick="location.href='/logout';">
            <h2>LOGOUT</h2>
        </div>
    </div>
    <?php endif; ?>

</main>