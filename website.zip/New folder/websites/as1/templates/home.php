<main>
			<h1>Welcome to Ed's Electronics</h1>

			<p>We stock a large variety of electrical goods including phones, tvs, computers and games. Everything comes with at least a one year guarantee and free next day delivery.</p>

			

			<h2>Product list</h2>

			<?php foreach($products as $product) { ?>

			
			<ul class="products" onclick="window.location.href='products?id=<?= $product['idproduct']; ?>'">

				<li>
				<h3><?= $product['product_name'] ?></h3>
					<h4>Category : <?= $product['category_name'] ?></h4>
					<h4>Manufacturer : <?= $product['product_manufacturer'] ?></h4>

					<p><?= $product['product_details'] ?></p>
					<div class="price">£<?= $product['product_price'] ?></div>
				</li>
				</a>

			</ul>

			<hr />
				<?php }?>
			
		</main>

		<aside>

			<h1><a href="#">Featured Product</a></h1>
			<p><strong>Gaming PC</strong></p>
			<p>Brand new 8 core computer with an RTX 4080 </p>

		</aside>