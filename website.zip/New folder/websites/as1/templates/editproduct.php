<main>
    <h1>EDIT PRODUCT</h1>

    <?php foreach ($products as $product): ?>
        <form action="editproduct" method="POST">
            <label for="name">New product Name:</label>
            <input type="text" name="product_name" value="<?= $product['product_name'] ?>" required />

            <input type="hidden" name="idproduct" value="<?= $product['idproduct'] ?>" />

            <label for="price">Product Price:</label>
            <input type="text" name="product_price" value="<?= $product['product_price'] ?>" required />

            <label for="Manufacture">Product Manufacture:</label>
            <input type="text" name="product_manufacturer" value="<?= $product['product_manufacturer'] ?>" required />

            <label for="description">Product Description:</label>
            <textarea name="product_details" required><?= $product['product_details'] ?></textarea>

            <label>Product Category</label> 


            <?php
            require('../database_connect.php');


            $query = $pdo->prepare('SELECT * FROM category');

            $query->execute();
            echo '<select name="idcategory">';
            while ($category =$query->fetch())
            {
                echo '<option value="'. $category['idcategory']. '">'.$category['category_name'].'</option>';
            }
            echo '</select>';
            ?>

            <!-- Submit button -->
            <input type="submit" value="EDIT" name="edit" />
        </form>
    <?php endforeach; ?>
</main>
