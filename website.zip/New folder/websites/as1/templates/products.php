

<main>
    <h2>Product Page</h2>

    <?php foreach ($products as $product): ?>
    <h3><?= $product['product_name'] ?></h3>
    <h4>Category: <?= $product['category_name'] ?></h4>
    <h4>Manufacturer : <?= $product['product_manufacturer'] ?></h4>
    <p><?= $product['product_details'] ?></p>
    <div class="price">£<?= $product['product_price'] ?></div>

        <h4>Product Reviews</h4>
        <ul class='reviews'>
            <?php foreach ($reviews as $review): ?>
                <li>
                    <p><?= $review['review_details'] ?></p>
                    <div class='details'>
                        <strong><?= $review['review_username'] ?></strong>
                        <em><?= $review['dateis'] ?></em>
                    </div>
                </li>
            <?php endforeach; ?>
        </ul>

        <h4>FAQs</h4>
        <ul class='reviews'>
            <?php foreach ($questions as $question): ?>
                <li>
                    <p><?= $question['question_details'] ?></p>
        

                    <div class='details'>
                        <strong><?= $question['question_username'] ?></strong>
                        <em><?= $question['dateis'] ?></em>
                    </div>
                    <p>Admin Reply :</p>
                    <p><?= $question['answer'] ?></p>
                </li>
            <?php endforeach; ?>
        </ul>



<h2>Ask Questions Or Add Reviews</h2>
<form action="products" method="post">
<label>Post :</label>

<select name="type">
        <option value="question">Question</option>
        <option value="review">Review</option>
    </select>
    <label>Write here:</label>
    <textarea name="content" ></textarea>
    <input type="hidden" name="idproduct" value="<?= $product['idproduct'] ?>" />

    <input type="submit" name="add" value="Submit" />
</form>

</main>

<aside>
    <h1><a href="#">Featured Product</a></h1>
    <p><strong>Gaming PC</strong></p>
    <p>Brand new 8-core computer with an RTX 4080</p>
</aside>
<?php endforeach; ?>
