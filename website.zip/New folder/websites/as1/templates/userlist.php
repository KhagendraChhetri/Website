

<main>
<h1>User Management</h1>
<h4 style="float: right;"><a href="adminregister">Add Admin</a></h4>
<?php if (isset($message)): ?>
        <p><?php echo $message; ?></p>
    <?php endif; ?>
    <table>
        <tr>
            <th>User Email</th>
            <th>Admin</th>
            <th></th>
        </tr>

        <?php foreach ($user as $user): ?>
            <tr>
                <td><?= $user['email'] ?></td>
                <td><?= $user['admin_priv'] == 1 ? 'Yes' : 'No' ?></td>
                <td>
                    <!-- Delete Button -->
                    <form action="userlist" method="POST">
								<input type="hidden" name="iduser" value="<?=$user['iduser']?>">
								<input type="submit" name="delete" value="DELETE" onclick="return confirm('Are you sure you want to delete this category?')">
							</form>                </td>
            </tr>
        <?php endforeach; ?>

    </table>


</main>