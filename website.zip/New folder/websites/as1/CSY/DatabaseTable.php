<?php
namespace CSY;
class DatabaseTable {
    private $pdo;
    private $table;
    private $primaryKey;

    public function __construct($pdo, $table, $primaryKey){
        $this->pdo = $pdo;
        $this->table = $table; 
        $this->primaryKey = $primaryKey; 
    }
 //to find the rows with certain values. university powerpoint and labwork
    public function find($field, $value){
        $stmt = $this->pdo->prepare('SELECT * FROM ' . $this->table . ' WHERE ' . $field . ' = :value');

        $criteria = [
            'value' => $value
        ];
        $stmt->execute($criteria);

        return $stmt->fetchAll();
    }

    public function findAll(){
        $stmt = $this->pdo->prepare('SELECT * FROM ' . $this->table );
        $stmt->execute();
        return $stmt->fetchAll();
    }

    public function insert($record){
        //insert function that should work for any table/ schema
        $keys = array_keys($record);
    
        $values = implode(', ', $keys);
        $placeholderValues = implode(', :', $keys);
    
        $query = 'INSERT INTO ' . $this->table . ' (' . $values . ') VALUES (:' . $placeholderValues . ')';
        $stmt = $this->pdo->prepare($query);
    
        $stmt->execute($record);
    }

    public function update($record){
        $query = 'UPDATE ' . $this->table . ' SET ';
    
        $parameters = []; // will store the key values(column name, placeholder, data)
        foreach ($record as $key => $value){
            $parameters[] = $key . ' = :' . $key;
        }
    
        $query .= implode(', ', $parameters);
        $query .= ' WHERE ' . $this->primaryKey . '= :primaryKey';
    
        $record['primaryKey'] = $record[$this->primaryKey];
    
        $stmt = $this->pdo->prepare($query);
        $stmt->execute($record);
    }
    
    public function save($record) {
        // combine insert & update functions using try/catch
        // this will always run the insert function, if that fails (record exists) then it will run the update function
        try {
            $this->insert($record);
        }
        catch (\Exception $e) {
            $this->update($record);
        }
    }

    public function delete($id){
        $stmt = $this->pdo->prepare('DELETE FROM ' . $this->table . ' WHERE ' . $this->primaryKey . ' = :id');
        $values = [
            'id' => $id
        ];
        $stmt->execute($values);
    }

    public function productwithcategory(){
				$stmt = $this->pdo->prepare('SELECT p.*, c.category_name as category_name
				FROM product p
				JOIN category c ON p.idcategory = c.idcategory
				ORDER BY p.idproduct DESC
				LIMIT 10');

				$stmt->execute();
            return $stmt->fetchAll();
    }

    

    public function productwithcategoryById($id) {
        $stmt = $this->pdo->prepare('SELECT p.*, c.category_name as category_name
            FROM product p
            JOIN category c ON p.idcategory = c.idcategory
            WHERE p.idproduct = :id
            LIMIT 1');
        
        $stmt->execute([':id' => $id]);
        
        return $stmt->fetchAll();
    }
    
        public function productReviewById($id) {
            $stmt = $this->pdo->prepare('SELECT p.*, r.idreview, r.review_details, r.dateis, u.username as review_username
                FROM product p
                JOIN review r ON p.idproduct = r.idproduct
                LEFT JOIN user u ON r.iduser = u.iduser
                WHERE p.idproduct = :id
            ');
    
            $stmt->execute([':id' => $id]);
            return $stmt->fetchAll();
           
        }
    

        public function productQnById($id) {
            $stmt = $this->pdo->prepare('SELECT p.*, q.idquestion, q.question_details, q.dateis, q.answer, q.display, u.username as question_username
                FROM product p
                JOIN question q ON p.idproduct = q.idproduct
                LEFT JOIN user u ON q.iduser = u.iduser
                WHERE p.idproduct = :id
                AND display = 1
            ');
    
            $stmt->execute([':id' => $id]);
            return $stmt->fetchAll();
           
        }
        //get questions and user email based on qn id
        public function userqna($id) {
            $stmt = $this->pdo->prepare('SELECT q.*, u.email as question_email
                FROM question q
                JOIN user u ON q.iduser = u.iduser
                WHERE q.idquestion = :id
            ');
        
            $stmt->execute([':id' => $id]);
            return $stmt->fetchAll();
        }
        
        //get qn based on user
        public function userqn($id) {
            $stmt = $this->pdo->prepare('SELECT q.*, u.iduser as userid
                FROM question q
                JOIN user u ON q.iduser = u.iduser
                WHERE u.iduser = :id
            ');
        
            $stmt->execute([':id' => $id]);
            return $stmt->fetchAll();
        }

        public function productsbyCategory($id) {
            $stmt = $this->pdo->prepare('SELECT p.*, c.category_name as category_name
                FROM product p
                JOIN category c ON p.idcategory = c.idcategory
                WHERE p.idcategory = :id
            ');

            $stmt->execute([':id' => $id]);
            return $stmt->fetchAll();
        }


}