<?php
namespace CSY;

interface Routes {
    public function getPage($route);
}
?>