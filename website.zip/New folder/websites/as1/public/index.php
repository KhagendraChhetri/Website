<?php
require '../autoload.php';
$routes = new \src\Routes();
$entryPoint = new \CSY\EntryPoint($routes);
$entryPoint->run();