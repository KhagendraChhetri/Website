<?php
namespace src;
class Routes {
    public function getPage($route) {
        require '../database_connect.php';
//defining
        $categoryTable = new \CSY\DatabaseTable($pdo, 'category', 'idcategory');
        $productTable = new \CSY\DatabaseTable($pdo, 'product', 'idproduct');
        $questionTable = new \CSY\DatabaseTable($pdo, 'question', 'idquestion');
        $reviewTable = new \CSY\DatabaseTable($pdo, 'review', 'idreview');
        $userTable = new \CSY\DatabaseTable($pdo, 'user', 'iduser');
//adding controllers
        $controllers = [];
        $controllers['category'] = new \src\Controllers\category($categoryTable);
        $controllers['product'] = new \src\Controllers\product($productTable);
        $controllers['question'] = new \src\Controllers\question($questionTable);
        $controllers['review'] = new \src\Controllers\review($reviewTable);
        $controllers['user'] = new \src\Controllers\user($userTable);

//use of switch case to redirect route page accordingly
    
        switch ($route) {
            case '':
                return $controllers['product']->home();
                break;

                case 'error':
                    return $controllers['product']->error();
                    break;
            //login
            case 'login':
                if (isset($_SESSION['loggedin']) ) {
                    header("Location: dashboard");
                    exit();            } 
                    else {
                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                    return $controllers['user']->loginSubmited();
                }
                    else  {
                        return $controllers['user']->login();
                    }
            }
                break;

            //dashboard
            case 'dashboard':
                if (isset($_SESSION['loggedin']) ) {
                    return $controllers['user']->dashboard();
            } else {
                header("Location: login");
                exit();
            }
                break;
            
            //registeration page
            case 'register':
                if (isset($_SESSION['loggedin']) ) {
                    header("Location: dashboard");
                    exit();            
                } 
                    else {
                        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                            return $controllers['user']->registrationSubmitted();
                        }
                            else  {
                                return $controllers['user']->register();
                            }
                     }
                 break;

                //logouts
                case 'logout':
                    return $controllers['user']->logout();
                    break;

                //product listings
                case 'productlist':
                    if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                            return $controllers['product']->deleteProduct();
                        }
                            else  {
                              
                        return $controllers['product']->productlist();
                            }
                    } else {
                        header("Location: dashboard");
                        exit();
                    }
                    break;


                        case 'editproduct':
                            if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                                    return $controllers['product']->geteditProduct();}
                                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                        return $controllers['product']->posteditProduct();
                                    }
                             }
                             else {
                                header("Location: /dashboard");
                                exit();
                            }
                            break;


                            case 'addproduct':
                                if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                            return $controllers['product']->addproductSubmit();
                                        }
                                        else{
                                            return $controllers['product']->addproduct();

                                        }
                                 }
                                 else {
                                    header("Location: /dashboard");
                                    exit();
                                }
                                break;
                                //category url routing
                                case 'categorylist':
                                    if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                            return $controllers['category']->deleteCategory();
                                        }
                                            else  {
                                              
                                        return $controllers['category']->categorylist();
                                            }
                                    } else {
                                        header("Location: dashboard");
                                        exit();
                                    }
                                    break;

                                    case 'addcategory':
                                        if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                                    return $controllers['category']->addcategorysubmit();
                                                }
                                                else{
                                                    return $controllers['category']->addcategory();
        
                                                }
                                         }
                                         else {
                                            header("Location: /dashboard");
                                            exit();
                                        }
                                        break;

                                        case 'editcategory':
                                            if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                                if ($_SERVER['REQUEST_METHOD'] == 'GET') {
                                                    return $controllers['category']->geteditCategory();}
                                                if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                                        return $controllers['category']->posteditCategory();
                                                    }
                                             }
                                             else {
                                                header("Location: /dashboard");
                                                exit();
                                            }
                                            break;

                                //users admin
                                case 'userlist':
                                    if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                            return $controllers['user']->deleteuser();
                                        }
                                            else  {
                                              
                                        return $controllers['user']->userlist();
                                            }
                                    } else {
                                        header("Location: dashboard");
                                        exit();
                                    }
                                    break;

                                    case 'adminregister':
                                        if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                            if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                                return $controllers['user']->adminregistrationSubmitted();
                                            }
                                                else  {
                                                  
                                            return $controllers['user']->adminregister();
                                                }
                                        } else {
                                            header("Location: dashboard");
                                            exit();
                                        }
                                        break;


                                    //product view

                                    case 'products':
                                        if (isset($_SESSION['loggedin'])) {
                                            if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['add'])) {
                                                $type = $_POST['type'];                                    
                                                switch ($type) {
                                                    case 'question':
                                
                                                        return $controllers['question']->addQuestion();
                                                    case 'review':
                                                        
                                                        return $controllers['review']->addReview();
                                                }
                                            } else {
                                                return $controllers['product']->productdetails();
                                            }
                                        } else {
                                            return $controllers['product']->productdetails();
                                        }
                                        break;
                                    
                                    

                            ///Product query admin
                            case 'questionlist':
                                if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                    if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                        return $controllers['question']->deleteQuestion();
                                    } elseif ($_SERVER['REQUEST_METHOD'] == 'GET') {
                                        if (isset($_GET['filter']) && $_GET['filter'] == 'unreplied') {
                                            return $controllers['question']->unrepliedqnlist();
                                        } else {
                                            return $controllers['question']->questionlist();
                                        }
                                    } 
                                } else {
                                    header("Location: dashboard");
                                    exit();
                                }
                                break;
                            


                                case 'response':
                                    if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                        if ($_SERVER['REQUEST_METHOD'] == 'POST') {
                                            return $controllers['question']->addResponse();
                                        }
                                            else  {
                                              
                                        return $controllers['question']->question();
                                            }
                                    } else {
                                        header("Location: dashboard");
                                        exit();
                                    }
                                    break;

                                    case 'myquestions':
                                        if (isset($_SESSION['loggedin']) && $_SESSION['role'] === 'admin') {
                                            
                                                  
                                            return $controllers['question']->questionlist();
                                                
                                        } 
                                        elseif (isset($_SESSION['loggedin'])){
                                            return $controllers['question']->userqna();
                                        }
                                        else {
                                            header("Location: dashboard");
                                            exit();
                                        }
                                        break;

                                        //productcategory nav view

                                        case 'productcategory':
                                            return $controllers['product']->productcategoryid();
                                            break;




            default:
            header("Location: error");
            exit();
                break;
        }
    }
}
