<?php
namespace src\Controllers;
class category {
    private $categoryTable;

    public function __construct($categoryTable){
        $this->categoryTable = $categoryTable;
    }

    //categorylist
    public function categorylist() {
        $category = $this->categoryTable->findAll();
    
        return ['template' => 'categorylist.php',
                'title' => 'Category List',
                'variables' => [
                    'category' => $category
                ]
                ];
            }

            //adding category via add cat page

            public function addCategory(){
            
                return [
                    'template' => 'addcategory.php',
                    'title' => ' Category Add',
                    'variables' => []
                ];
            }

            public function addcategorysubmit() {
                    
                if (array_key_exists('add', $_POST)) {
                $category = [
                    'category_name' => $_POST['category_name']
                ];
                $this->categoryTable->save($category);

                    if ($category === null) {
                        return [
                            'template' => 'error.php',
                            'title' => 'Error',
                            'variables' => []
                        ];
                    }
                    
                    $category = $this->categoryTable->findAll();

                    return [
                        'template' => 'categorylist.php',
                        'title' => 'Category List',
                        'variables' => [
                            'message' => 'Successfully Added!',
                            'category' => $category

                        ]
                    ];
                }
            }
            
            //
            
            public function deleteCategory() {
                            
                if (array_key_exists('delete', $_POST)) {
                        $this->categoryTable->delete($_POST['idcategory']);
                        $category = $this->categoryTable->findAll();
    
                        return [
                            'template' => 'categorylist.php',
                            'title' => 'Category List',
                            'variables' => [
                                'message' => 'Successfully deleted!',
                                'category' => $category
    
                            ]
                        ];
                    }
                }
    
                public function geteditCategory() {
                    $id = $_GET['id'] ?? null;
                    $category = $this->categoryTable->find('idcategory',$id);
                    
                
                    if (empty($category)) {
                        return [
                            'template' => 'error.php',
                            'title' => 'Error',
                            'variables' => []
                        ];
                    }
                    
                    return [
                        'template' => 'editcategory.php',
                        'title' => 'Edit Category',
                        'variables' => [
                            'category' => $category
                        ]
                    ];
                }
    
                public function posteditCategory() {
                    if (array_key_exists('edit', $_POST)) {
                    $category = [
                        'idcategory' => $_POST['idcategory'],
                        'category_name' => $_POST['category_name']
                    ];
                    $this->categoryTable->save($category);
    
                        if ($category === null) {
                            return [
                                'template' => 'error.php',
                                'title' => 'Error',
                                'variables' => []
                            ];
                        }
                        
                        $category = $this->categoryTable->findAll();
    
                        return [
                            'template' => 'categorylist.php',
                            'title' => 'Category List',
                            'variables' => [
                                'message' => 'Successfully Edited!',
                                'category' => $category
    
                            ]
                        ];
                    }
                }
    
                
    
                



}