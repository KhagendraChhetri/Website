<?php
namespace src\Controllers;
class review {
    private $reviewTable;

    public function __construct($reviewTable){
        $this->reviewTable = $reviewTable;
    }



    
    public function addReview() {
        $currentDate = date('Y-m-d');

                
        if (array_key_exists('add', $_POST)) {

        $content = $_POST['content'];
        $type = $_POST['type'];
        
        if ($type == 'review' && $content) {
            // Handle question submission
            $review = [
                'review_details' => $_POST['content'],
                'idproduct' => $_POST['idproduct'],
                'iduser' => $_SESSION['iduser'],
                'dateis' => $currentDate
            ];
            $this->reviewTable->save($review);

            header('Location: /');
            exit;
        } 
        else {
                return [
                    'template' => 'error.php',
                    'title' => 'Error',
                    'variables' => []
                ];        }
    } else {
        return [
            'template' => 'error.php',
            'title' => 'Error',
            'variables' => []
        ];
    }

       
            }
    

 
    // nav bar edit?? Filter questions to show only unanswered questions
    //filter  qns to show unreplied ones

}

   