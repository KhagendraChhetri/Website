<?php
namespace src\Controllers;
class question {
    private $questionTable;

    public function __construct($questionTable){
        $this->questionTable = $questionTable;
    }

    public function addQuestion() {
        $currentDate = date('Y-m-d');

                
        if (array_key_exists('add', $_POST)) {

        $content = $_POST['content'];
        $type = $_POST['type'];
        
        if ($type == 'question' && $content) {
            // Handle question submission
            $question = [
                'question_details' => $_POST['content'],
                'idproduct' => $_POST['idproduct'],
                'iduser' => $_SESSION['iduser'],
                'dateis' => $currentDate
            ];
            $this->questionTable->save($question);

            header('Location: /');
            exit;
        } 
        else {
                return [
                    'template' => 'error.php',
                    'title' => 'Error',
                    'variables' => []
                ];        }
    } else {
        return [
            'template' => 'error.php',
            'title' => 'Error',
            'variables' => []
        ];
    }

       
            }

            //QN MANAGEMENT

            public function questionList() {
                $question = $this->questionTable->findAll();
            
                return ['template' => 'questionlist.php',
                        'title' => 'QN List',
                        'variables' => [
                            'questions' => $question
                            ]
                        ];
                    }

                    //response and delete option

                    public function deletequestion() {
                            
                        if (array_key_exists('delete', $_POST)) {
                                $this->questionTable->delete($_POST['idquestion']);
                                $question = $this->questionTable->findAll();
            
                                return [
                                    'template' => 'questionlist.php',
                                    'title' => 'Question List',
                                    'variables' => [
                                        'message' => 'Successfully deleted!',
                                        'questions' => $question
            
                                    ]
                                ];
                            }
                        }

                        //response

                        public function question() {
                            $id = $_GET['id'] ?? null;
                        
                            if ($id) {
                                $question = $this->questionTable->userqna($id);
                                
                                return [
                                    'template' => 'response.php',
                                    'title' => 'Response',
                                    'variables' => [
                                        'questions' => $question
                                    ]
                                ];
                            } else {
                                return [
                                    'template' => 'error.php',
                                    'title' => 'Error',
                                    'variables' => []
                                ];
                            }
                        }
                        


                        //response
                        public function addResponse() {

                
                            if (array_key_exists('reply', $_POST)) {
                    
                            $content = $_POST['content'];
                            $type = $_POST['type'];
                            
                            if ($type == 'show' && $content) {
                                // Handle question submission
                                $questions = [
                                    'idquestion' => $_POST['idquestion'],
                                    'answer' => $_POST['content'],
                                    'display' => '1',
                                    'response' => '1'

                                ];
                                $this->questionTable->save($questions);
                    
                                $question = $this->questionTable->findAll();
            
                                return ['template' => 'questionlist.php',
                                        'title' => 'QN List',
                                        'variables' => [
                                            'questions' => $question
                                            ]
                                        ];
                            }
                            
                            
                            if ($type == 'hide' && $content) {
                                $questions = [
                                    'idquestion' => $_POST['idquestion'],
                                    'answer' => $_POST['content'],
                                    'response' => '1',
                                    'display' => '0'


                                    //'dateis' => $_POST['dateis']
                                ];
                                $this->questionTable->save($questions);
                    
                                $question = $this->questionTable->findAll();
            
                                return ['template' => 'questionlist.php',
                                        'title' => 'QN List',
                                        'variables' => [
                                            'questions' => $question
                                            ]
                                        ];

                            }
                            else {
                                    return [
                                        'template' => 'error.php',
                                        'title' => 'Error',
                                        'variables' => []
                                    ];        }
                        } else {
                            return [
                                'template' => 'error.php',
                                'title' => 'Error',
                                'variables' => []
                            ];
                        } }

                        //user qns

                        public function userqna() {
                            $id = $_SESSION['iduser'];
                            $question = $this->questionTable->userqn($id);
                        
                            if($question){
                            return ['template' => 'myquestions.php',
                                    'title' => 'QN List',
                                    'variables' => [
                                        'questions' => $question
                                        ]
                                    ];
                                }
                                else{
                                    return ['template' => 'myquestions.php',
                                    'title' => 'QN List',
                                    'variables' => [
                                        'message' => 'No question available sorry',
                                        'questions' => $question

                                        ]
                                    ];
                                }}


                                ///
                                public function unrepliedqnlist()
                                {
                                    $question = $this->questionTable->find('response', '0');
                                
                                    return ['template' => 'questionlist.php',
                                            'title' => 'QN List',
                                            'variables' => [
                                                'questions' => $question
                                                ]
                                            ];
                                        }
}