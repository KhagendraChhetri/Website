<?php
namespace src\Controllers;
class product {
    private $productTable;
//use of product table to access of database 
    public function __construct($productTable){
        $this->productTable = $productTable;
    }


    public function home(){
        $products = $this->productTable->productwithcategory();


        return [
            'template' => 'home.php',
            'title' => ' product Database',
            'variables' => [
                'products' => $products
            ]
        ];
    }
    
   // 
   public function productlist() {
    $products = $this->productTable->findAll();

    return ['template' => 'productlist.php',
            'title' => 'Product List',
            'variables' => [
                'products' => $products
            ]
            ];
        }
        
        
        public function deleteProduct() {
                        
            if (array_key_exists('delete', $_POST)) {
                    $this->productTable->delete($_POST['idproduct']);
                    $products = $this->productTable->findAll();

                    return [
                        'template' => 'productlist.php',
                        'title' => 'Product List',
                        'variables' => [
                            'message' => 'Successfully deleted!',
                            'products' => $products

                        ]
                    ];
                }
            }

            public function geteditProduct() {
                $id = $_GET['id'] ?? null;
                $products = $this->productTable->productwithcategoryById($id);
                
            
                if (empty($products)) {
                    return [
                        'template' => 'error.php',
                        'title' => 'Error',
                        'variables' => []
                    ];
                }
                
                return [
                    'template' => 'editproduct.php',
                    'title' => 'Edit products',
                    'variables' => [
                        'products' => $products
                    ]
                ];
            }

            public function posteditProduct() {
                if (array_key_exists('edit', $_POST)) {
                $products = [
                    'idproduct' => $_POST['idproduct'],
                    'product_name' => $_POST['product_name'],
                    'product_price' => $_POST['product_price'],
                    'product_manufacturer' => $_POST['product_manufacturer'],
                    'product_details' => $_POST['product_details'],
                    'idcategory' => $_POST['idcategory']
                ];
                $this->productTable->save($products);

                    if ($products === null) {
                        return [
                            'template' => 'error.php',
                            'title' => 'Error',
                            'variables' => []
                        ];
                    }
                    
                    $products = $this->productTable->findAll();

                    return [
                        'template' => 'productlist.php',
                        'title' => 'Product List',
                        'variables' => [
                            'message' => 'Successfully Edited!',
                            'products' => $products

                        ]
                    ];
                }
            }

            public function addproduct(){
        
                $error= [];
                return [
                    'template' => 'addproduct.php',
                    'title' => ' product Add',
                    'variables' => [

                    ]
                ];
            }

            public function addproductSubmit() {
                
                if (array_key_exists('add', $_POST)) {
                $products = [
                    'product_name' => $_POST['product_name'],
                    'product_price' => $_POST['product_price'],
                    'product_manufacturer' => $_POST['product_manufacturer'],
                    'product_details' => $_POST['product_details'],
                    'idcategory' => $_POST['idcategory']
                ];
                $this->productTable->save($products);

                    if ($products === null) {
                        return [
                            'template' => 'error.php',
                            'title' => 'Error',
                            'variables' => []
                        ];
                    }
                    
                    $products = $this->productTable->findAll();

                    return [
                        'template' => 'productlist.php',
                        'title' => 'Product List',
                        'variables' => [
                            'message' => 'Successfully Added!',
                            'products' => $products

                        ]
                    ];
                }
            }


            //product view
            public function productdetails() {
                $id = $_GET['id'] ?? null;
                $products = $this->productTable->productwithcategoryById($id);
                $reviews = $this->productTable->productReviewById($id);
                $questions = $this->productTable->productQnById($id);


        
                if (empty($products)) {
                    return [
                        'template' => 'error.php',
                        'title' => 'Error',
                        'variables' => []
                    ];
                }
        
                return [
                    'template' => 'products.php',
                    'title' => 'Product Details',
                    'variables' => [
                        'products' => $products,
                        'reviews' => $reviews,
                        'questions' => $questions

                    ]
                ];
            }
            
            //**** */
  

 
    
    public function productcategoryid(){
        
        $id = $_GET['id'] ?? null;
        $products = $this->productTable->productsbyCategory($id);
    
        if (empty($products)) {
            return ['template' => 'error.php',
                    'title' => 'Error',
                    'variables' => [
                        
                    ]
            ];
        }
    
        return ['template' => 'productcategory.php',
                'title' => 'product List',
                'variables' => [
                    'products' => $products
                ]
        ];
    }
    public function error() {
        return [
           
            'template' => 'error.php',
            'variables' => [
                
            ],
            'title' => 'error'
        ];
    }

    /////

}