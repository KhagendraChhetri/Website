<?php
namespace src\Controllers;
class user {
    private $userTable;

    public function __construct($userTable){
        $this->userTable = $userTable;
    }

    public function login() {
        // display the form.
        if (!isset($_SESSION['loggedout'])) {
    
            return [
                    'title' => 'Log in',
                    'template' => 'login.php',
                    'variables' =>[]
            ];
        }
        else {
           echo 'You are already logged in';
    }}

    public function loginSubmited(){
        if (array_key_exists('login', $_POST)) {
            $email = $_POST['email'];
            $password = $_POST['password'];
    
            // Check in the 'users' table
            $user = $this->userTable->find('email', $email);
    
            if (empty($user) || !password_verify($password, $user[0]['password'])) {
                // If user is not found or password is incorrect, display an error message
                return [
                    'template' => 'login.php', 
                    'title' => 'Login',
                    'variables' => [
                        'message' => 'Wrong email or password. Please try again. '
                    ]
                ];
            }
    
            // If the user is found and the password is correct, set session variables
            $_SESSION['loggedin'] = true;
            $_SESSION['iduser'] = $user[0]['iduser'];
            $_SESSION['username'] = $user[0]['username'];
        
            // Set the role based on the value in 'admin_priv' column
            $_SESSION['role'] = ($user[0]['admin_priv'] == 1) ? 'admin' : 'client';
    
            return [
                'template' => 'dashboard.php',
                'title' => 'Dashboard',
                'variables' => [
                    'user' => $user[0]
                ]
            ];
        }
    }
    
    

            //dashboard
            public function dashboard() {
                // display the form.
           
                    return [
                            'title' => 'Log in',
                            'template' => 'dashboard.php',
                            'variables' =>[
                            ]
                    ];
                }
             
        
                public function registrationSubmitted(){
                    $error = [];
                
                    if (isset($_POST['register'])) {
                        if (empty($_POST['email'])) {
                            $error['email'] = 'You must enter an email';
                        }
                
                        // Check if already exists
                        $existingUser = $this->userTable->find('email', $_POST['email']);
                        if (!empty($existingUser)) {
                            $error['email'] = 'Email is already registered. Please use a different email.';
                        }
                
                        if (empty($_POST['username'])) {
                            $error['username'] = 'You must enter a username';
                        }
                
                        if (empty($_POST['password'])) {
                            $error['password'] = 'You must enter a password';
                        }
                
                        if (empty($error)) {
                            $insert = [
                                'admin_priv' => '0',
                                'username' => $_POST['username'],
                                'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                                'email' => $_POST['email']
                            ];
                            $this->userTable->insert($insert);

                
                            return [
                                'template' => 'login.php',
                                'title' => 'Login',
                                'variables' => [
                                    'message' => 'Successfully registered now Login !'

                                ]
                            ];
                        }
                    }
                
                    //  return to the registration page with error messages
                    return [
                        'template' => 'register.php',
                        'title' => 'Register',
                        'variables' => [
                            'error' => $error
                        ]
                    ];
                }
                
                public function register() {
                    return [
                        'template' => 'register.php',
                        'title' => 'Register',
                        'variables' => [
                            'error' => []
                        ]
                    ];
                }
                


               //logouts
               public function logout() {
                // Destroy the session
                session_destroy();
            
                // Redirect to the login page or any other desired page
                header('Location: /');
                exit;
            }



            //user management
            public function userlist() {
                $user = $this->userTable->findAll();
            
                return ['template' => 'userlist.php',
                        'title' => 'User List',
                        'variables' => [
                            'user' => $user
                            ]
                        ];
                    }


                    public function deleteuser() {
                            
                        if (array_key_exists('delete', $_POST)) {
                                $this->userTable->delete($_POST['iduser']);
                                $user = $this->userTable->findAll();
            
                                return [
                                    'template' => 'userlist.php',
                                    'title' => 'User List',
                                    'variables' => [
                                        'message' => 'Successfully deleted!',
                                        'user' => $user
            
                                    ]
                                ];
                            }
                        }

                        public function adminregister() {
                            return [
                                'template' => 'adminregister.php',
                                'title' => 'Admin Register',
                                'variables' => [
                                    'error' => []
                                ]
                            ];
                        }

                        public function adminregistrationSubmitted(){
                            $error = [];
                
                            if (isset($_POST['register'])) {
                                if (empty($_POST['email'])) {
                                    $error['email'] = 'You must enter an email';
                                }
                        
                                // Check if already exists
                                $existingUser = $this->userTable->find('email', $_POST['email']);
                                if (!empty($existingUser)) {
                                    $error['email'] = 'Email is already registered. Please use a different email.';
                                }
                        
                                if (empty($_POST['username'])) {
                                    $error['username'] = 'You must enter a username';
                                }
                        
                                if (empty($_POST['password'])) {
                                    $error['password'] = 'You must enter a password';
                                }
                        
                                if (empty($error)) {
                                    $insert = [
                                        'admin_priv' => '1',
                                        'username' => $_POST['username'],
                                        'password' => password_hash($_POST['password'], PASSWORD_DEFAULT),
                                        'email' => $_POST['email']
                                    ];
                                    $this->userTable->insert($insert);
                                    $user = $this->userTable->findAll();

        
                        
                                    return [
                                        'template' => 'userlist.php',
                                        'title' => 'User List',
                                        'variables' => [
                                            'message' => 'Successfully registered  !',
                                            'user' => $user

        
                                        ]
                                    ];
                                }
                                return [
                                    'template' => 'adminregister.php',
                                    'title' => 'Admin Register',
                                    'variables' => [
                                        'error' => $error
                                    ]
                                ];
                            }
                        
                            //  return to the registration page with error messages
                            return [
                                'template' => 'adminregister.php',
                                'title' => 'Admin Register',
                                'variables' => [
                                    'error' => $error
                                ]
                            ];
                        }
            

                       
}