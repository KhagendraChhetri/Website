-- MariaDB dump 10.19  Distrib 10.5.19-MariaDB, for Linux (x86_64)
--
-- Host: mysql    Database: as1
-- ------------------------------------------------------
-- Server version	11.2.2-MariaDB-1:11.2.2+maria~ubu2204

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Current Database: `as1`
--

CREATE DATABASE /*!32312 IF NOT EXISTS*/ `as1` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_general_ci */;

USE `as1`;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `category` (
  `idcategory` int(11) NOT NULL AUTO_INCREMENT,
  `category_name` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`idcategory`)
) ENGINE=InnoDB AUTO_INCREMENT=102 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (2,'Electronics'),(3,'Fashion'),(4,'Home & Living'),(5,'Books'),(8,'Sports & Outdoors'),(13,'Others');
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product` (
  `idproduct` int(11) NOT NULL AUTO_INCREMENT,
  `product_name` varchar(200) NOT NULL,
  `product_details` varchar(200) DEFAULT NULL,
  `product_price` varchar(45) DEFAULT 'NA',
  `idcategory` int(11) DEFAULT NULL,
  `product_manufacturer` varchar(200) DEFAULT 'NA',
  PRIMARY KEY (`idproduct`),
  KEY `fk_idcategory_idx` (`idcategory`),
  CONSTRAINT `fk_idcategory` FOREIGN KEY (`idcategory`) REFERENCES `category` (`idcategory`) ON DELETE NO ACTION ON UPDATE NO ACTION
) ENGINE=InnoDB AUTO_INCREMENT=97 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (81,'TechGizmo X1','The TechGizmo X1 is a cutting-edge smartphone with a sleek design, powerful processor, and an impressive camera system. It\'s perfect for tech enthusiasts who demand top-notch performance.','699',2,'TechGizmo'),(82,'SmartWatch Pro','The SmartWatch Pro combines style with functionality, featuring health tracking, notifications, and a durable design. Stay connected in style with this smart accessory.','149.99',2,'Xaomi'),(83,'UrbanChic Backpack','The UrbanChic Backpack is a trendy and spacious accessory, perfect for both work and travel. Its stylish design and multiple compartments make it a must-have fashion statement.','50',3,'Zara'),(84,'Sunglasses','Vogue Sunglasses blend fashion and UV protection seamlessly. Elevate your style with these chic shades, offering both aesthetics and eye care.','129.99',3,'Vogue'),(85,'CozyComfort Bedding Set','Experience ultimate comfort with the CozyComfort Bedding Set. Made from premium materials, it ensures a good night\'s sleep while adding a touch of elegance to your bedroom.','175',4,'Ikea'),(86,'SmartHome Security System',' Enhance your home security with the SmartHome Security System. Monitor your property remotely, receive alerts, and ensure peace of mind with this advanced system.','299.99',2,'LG'),(87,'Mindful Living Guide','The Mindful Living Guide offers practical tips and exercises for cultivating mindfulness in everyday life. A must-read for those seeking balance and inner peace','15',5,'JKO'),(88,'Sci-Fi Adventure Chronicles','Immerse yourself in the Sci-Fi Adventure Chronicles, a gripping collection of futuristic tales filled with intergalactic adventures, mind-bending technologies, and unexpected twists.','29.99',5,'DC'),(89,'TrailBlazer Hiking Boots','Conquer any trail with TrailBlazer Hiking Boots. Designed for durability and comfort, these boots provide the support needed for your outdoor adventures','250',8,'North Face'),(90,'MegaPixel DSLR Camera','Capture stunning moments with the MegaPixel DSLR Camera. With high-resolution capabilities and advanced features, it\'s the perfect tool for aspiring and professional photographers alike.','1250',2,'Canon'),(91,'Trendsetter Handbag','Stay on-trend with the Trendsetter Handbag. Featuring a chic design and spacious interior, it\'s the perfect accessory for fashion-forward individuals.','79.99',4,'Zara'),(92,'SmartKitchen Blender','Revolutionize your kitchen with the SmartKitchen Blender. From smoothies to soups, this versatile appliance offers powerful performance with smart technology.','50.50',4,'Argos'),(93,'AeroSpeed Racing Bike','Experience the thrill of speed with the AeroSpeed Racing Bike. Designed for performance, it\'s the ideal choice for cycling enthusiasts and competitive riders.','1299',8,'BMW'),(94,'Radiant Glow Skincare Set','Achieve a radiant complexion with the Radiant Glow Skincare Set. This comprehensive skincare regimen includes cleanser, toner, and moisturizer to enhance your natural beauty.','49.99',13,'B&b'),(96,'Ebike','This is a demo bike by bmx','2500',8,'BMX');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `question`
--

DROP TABLE IF EXISTS `question`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `question` (
  `idquestion` int(11) NOT NULL AUTO_INCREMENT,
  `question_details` varchar(400) NOT NULL,
  `iduser` int(11) NOT NULL,
  `answer` varchar(400) DEFAULT 'Thank you for your question. Admin will get back soon.',
  `response` tinyint(1) NOT NULL DEFAULT 0,
  `idproduct` int(11) NOT NULL,
  `dateis` date DEFAULT NULL,
  `display` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`idquestion`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `question`
--

LOCK TABLES `question` WRITE;
/*!40000 ALTER TABLE `question` DISABLE KEYS */;
INSERT INTO `question` VALUES (10,'Does this have dual sim?',20,'Yes It does.',1,81,'2024-01-05',1),(11,'Does this have water ips rating?',20,'Thank you for your question. Admin will get back soon.',1,82,'2024-01-05',1),(12,'Does this have wireless fast charging?',6,'Thank you for your question. Admin will get back soon.',1,81,'2024-01-05',1),(13,'Can I pick my call via this smart watch?',6,'Yes you can',1,82,'2024-01-05',1),(14,'What is its iso range?',6,'Thank you for your question. Admin will get back soon.',0,90,'2024-01-05',0),(15,'Is it a4 or a5 size? the book',6,'Thank you for your question. Admin will get back soon.',0,88,'2024-01-05',0);
/*!40000 ALTER TABLE `question` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `review`
--

DROP TABLE IF EXISTS `review`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `review` (
  `idreview` int(11) NOT NULL AUTO_INCREMENT,
  `iduser` int(11) NOT NULL,
  `idproduct` int(11) NOT NULL,
  `dateis` date DEFAULT NULL,
  `review_details` varchar(400) NOT NULL,
  PRIMARY KEY (`idreview`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `review`
--

LOCK TABLES `review` WRITE;
/*!40000 ALTER TABLE `review` DISABLE KEYS */;
INSERT INTO `review` VALUES (1,1,1,NULL,'aaaaaaa'),(2,5,1,NULL,'XXXXX'),(3,1,8,NULL,'s'),(4,1,8,NULL,'xax'),(5,1,8,NULL,'w'),(6,1,8,NULL,'qq'),(7,20,8,NULL,'nice website'),(8,20,8,'2023-12-26','date'),(9,20,95,'2024-01-05','Nice product!! Love it'),(10,20,94,'2024-01-05','Nice product!! love it'),(11,20,93,'2024-01-05','Nice product!! love it'),(12,20,92,'2024-01-05','Nice product!! love it'),(13,20,91,'2024-01-05','Nice product!! love it'),(14,20,90,'2024-01-05','Nice product!! love it'),(15,20,89,'2024-01-05','Nice product!! love it'),(16,6,86,'2024-01-05','Nice product!!'),(17,6,81,'2024-01-05','Nice product!! love it');
/*!40000 ALTER TABLE `review` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user` (
  `iduser` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(200) NOT NULL,
  `password` varchar(200) NOT NULL,
  `email` varchar(200) NOT NULL,
  `admin_priv` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`iduser`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'kc@gmail.com','$2y$10$VIyYiIa97Ueb1RfMhOX6W.BH9lNlnmZOqnUAipuZ6Yyk0hLhKuf52','kc@gmail.com',1),(3,'1@1.1','$2y$10$gckKL9qqXmd33DyDIdo08.ePQJIzBdBL0ETqY1x0N6foVW2T.c4jW','1@1.1',1),(6,'a@b.z','$2y$10$nAe9ctvZo8oUEDacUP2rA.ejS7Y263FCRf4OnopZHAN7yf9cRiPDy','a@b.z',0),(20,'user@123.456','$2y$10$wKq9vrvjI1.IoAPC6WYrAOKFAGfNmiRhtmcdo2XK7GZiKr31TP4q.','user@123.456',0);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'as1'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-01-11 14:42:28
